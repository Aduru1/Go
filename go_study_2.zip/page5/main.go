package main

import "fmt"

func main() {
    name1 := "Ken the Ninja"
    name2 := "Master White"
    name3 := "Ben the Baby"
    
    // Using newline characters, print each strings on a separate line
    fmt.Printf("Welcome, %s\n", name1)
    fmt.Printf("Welcome, %s\n", name2)
    fmt.Printf("Welcome, %s\n", name3)
}
