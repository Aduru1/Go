package main

import "fmt"

func main() {
    month := 9
    day := 5
    
    // Using fmt.Printf with the month and day variables,
    // print out 「The date today is _/_」
    fmt.Printf("The date today is %d/%d",month,day)
    
}
