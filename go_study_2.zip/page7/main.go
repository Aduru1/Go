package main
import "math/rand"
import "fmt"
// Import the math/rand package


func main() {
    
    for i := 1; i <= 5; i++ {
        // Generate and print a random integer from 0 to 9
        fmt.Println(rand.Intn(10))
    }
}
