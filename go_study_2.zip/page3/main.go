package main

import "fmt"

func main() {
    weather := "sunny"
    // Using fmt.Printf with the weather variable,
    // print out 「Today, the weather is ____」
    fmt.Printf("%s %s","Today, the weather is ",weather)    

}
