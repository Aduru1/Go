package main

func main() {
     println("Hello, world")
    //,comment out this line
    
   // This line should be a comment
    
}
