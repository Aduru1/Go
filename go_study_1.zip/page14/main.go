package main

func main() {
    money := 100
    price := 200
    
    // Add an else statement
    if money >= price {
        println("You can buy this product")
    } else{
        println("You don't have enough money")
    }
    
    
}
