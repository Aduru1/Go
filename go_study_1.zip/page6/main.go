package main

func main() {
    // Combine strings to print the string "Hello, world"
    println("Hello,"+"world")
    
    // Combine the strings "38" and "19" and then print it
    println("38"+"19")
    
    // Print the sum of 38 and 19
    println(38+19)

}
