package main

func main() {
    n := 100
    // Subtract 10 from n and then assign the result to n
    n-=10
    
    println(n)
    
    
    m := 10
    // Add 1 to m and then assign the result to m
    m++
    
    println(m)
}
