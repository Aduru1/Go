package main

func main() {
    // Print the value of 12 divided by 3
    println(12/3)
    
    // Print the value of 3 multiplied by 6
    println(3*6)
    
    // Print the remainder after dividing 8 by 3
    println(8%3)
    
}
